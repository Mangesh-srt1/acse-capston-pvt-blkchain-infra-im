# Eagle Airlines: A blockchain based Ticket Management System

This is a capstone project to showcase our learning and understanding of blockchain and cloud computing concepts. We are using solidity to build the necessary contracts on ethereum and deployed a private blockchain in the cloud on EC2 instances with the nodes running on geth. 

# Files
- Airline.sol
- IFlight.sol 
- Flight.sol 
- Booking.sol 

### Airline.sol
Contains logic for airline management. Flights creation, booking creation would be here.

### IFlight.sol
Contains function signatures and enums that are used in other contracts. This is to enable interaction with the Flight contract without importing the entire contract code. 

### Flight.sol
Contains flight management logic. Booking seats, allowing airline to update flight status, get seat availability, etc would be here

### Booking.sol
Contains booking management logic. This contract will be created by the Airline every time a booking is created for a customer account. The customer can then deposit funds to this account to confirm the booking. It will act as an escrow and release funds when the flight has reached its destination or a customer makes a claim. It allows booking cancellation, computes delay and cancellation penalty and transfers funds to the respective parties.

## UML diagrams

Sample Booking and Flight cancellation flow:

```mermaid
sequenceDiagram
Airline ->> Booking: createBooking(customer, flight details)
Customer -->> Booking: deposit(amount)
Airline -->> Flight: updateStatus(cancelled)
Booking -->> Flight: getStatus
Booking -->> Customer: refund
```
